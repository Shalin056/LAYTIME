"""
module to generate
the metadata for the
rbac screens
"""


def determine_rbac_metadata():
    """
    Purpose: Meta data for app
    Returns: list
    """

    auth_section_meta = {
        'sectionName': 'Authorization',
        'icon': 'fa fa-shield',
        'screens': [
            {"screen": "Users",
             "type": "rbac",
             "title": "Users"},
            {"screen": "Groups",
             "type": "rbac",
             "title": "Groups"},
            {"screen": "Permissions",
             "type": "rbac",
             "title": "Permissions"}
        ]
    }

    workflow_section_meta = {
        'sectionName': 'Workflow',
        'icon': 'fa fa-table',
        'screens': [

        ]
    }

    meta_list = [auth_section_meta, workflow_section_meta]
    return meta_list


class RbacMetadata:
    """
    Purpose: Custom Metadata class defined in Settings
    """

    @staticmethod
    def determine_metadata(request):
        """
        Purpose: Overridden Function for custom HTTP OPTION CALLS
        Returns: Meta Data
        """
        if request.query_params.get('set') == "appmeta":
            return determine_rbac_metadata()
        return None
