# pylint: disable = E0401,C0301,C0111,R0903,R0201
"""
Helper functions which can be utilized
"""

from django.contrib.auth.models import Group, User, Permission
from jsonpickle import json

from rbac.constants import PERMISSIONS_GET_FUNCTIONS, \
    GROUPS_GET_FUNCTIONS, USERS_GET_FUNCTIONS


def get_request_object(req_json):
    """
    Purpose: To format Json and convert str to Object
    :param req_json: Json string
    :type req_json: str
    :return: Converted object from json
    :rtype: Dict
    """

    request = str(req_json).replace("'", '"')
    return json.loads(request)


def add_users_to_group(users, group):
    """
    Purpose: Add users to group
    :param users: user id list
    :type users: List
    :param group: Group Object
    :type group: Group Object
    """

    for user_id in users:
        user = User.objects.get(id=user_id)
        group.user_set.add(user)


def add_groups_to_user(groups, user):
    """
    Purpose: Assign Groups of a user
    :param groups: group id list
    :type groups: List
    :param user: User Object
    :type user: User Object
    """

    for group_id in groups:
        group = Group.objects.get(id=group_id)
        group.user_set.add(user)


def remove_user_from_groups(user):
    """
    Purpose: To remove user from all groups
    :param user: User Object
    :type user: User Object
    """

    old_groups = user.groups.all()
    for group in old_groups:
        group.user_set.remove(user)


def remove_users_in_group(group):
    """
    Purpose: To remove all users from a group
    :param group: Group Object
    :type group: Group Object
    """

    old_users = group.user_set.all()
    for user in old_users:
        group.user_set.remove(user)


def remove_permissions_from_user(user, model):
    """
    Purpose: To remove all permissions from the user based on model
    :param user: Selected user object
    :type user: User Object
    :param model: Model name
    :type model: str
    """

    old_permissions = Permission.objects.filter(user=user,
                                                content_type__model=model)
    for permission in old_permissions:
        user.user_permissions.remove(permission)


def add_permissions_to_user(user, permissions):
    """
    Purpose: To add all permissions from the user
    :param user: Selected user object
    :type user: User Object
    :param permissions: List of permission id
    :type permissions: list
    """

    for permission in permissions:
        selected_permission = Permission.objects.get(id=permission)
        user.user_permissions.add(selected_permission)


def remove_permissions_from_group(group, model):
    """
    Purpose: To remove all permissions from the group based on model
    :param group: Selected group object
    :type group: Group Object
    :param model: Model name
    :type model: str
    """

    old_permissions = group.permissions.filter(content_type__model=model)
    for permission in old_permissions:
        group.permissions.remove(permission)


def add_permissions_to_group(group, permissions):
    """
    Purpose: To add all permissions from the group
    :param group: Selected group object
    :type group: Group Object
    :param permissions: List of permission id
    :type permissions: list
    """

    for permission in permissions:
        selected_permission = Permission.objects.get(id=permission)
        group.permissions.add(selected_permission)


def permission_get_func_selector(kwargs, request):
    """
    Purpose: To determine function based on keywords
    :param kwargs: Network Request object keywords arguments
    :type kwargs: List
    :param request: Network Request object
    :type request: Request Object
    :return: Function name
    :rtype: str
    """

    if 'id' in kwargs:
        return PERMISSIONS_GET_FUNCTIONS['id']
    elif 'model' in kwargs:
        if 'user' in request.GET:
            return PERMISSIONS_GET_FUNCTIONS['user']
        elif 'group' in request.GET:
            return PERMISSIONS_GET_FUNCTIONS['group']
        else:
            return PERMISSIONS_GET_FUNCTIONS['model']
    else:
        return PERMISSIONS_GET_FUNCTIONS['all']


def group_get_func_selector(kwargs):
    """
    Purpose: To determine function based on keywords
    :param kwargs: Network Request object keywords arguments
    :type kwargs: List
    :return: Function name
    :rtype: str
    """

    if 'id' in kwargs:
        return GROUPS_GET_FUNCTIONS['id']
    elif 'user' in kwargs:
        return GROUPS_GET_FUNCTIONS['user']
    else:
        return GROUPS_GET_FUNCTIONS['all']


def user_get_func_selector(kwargs):
    """
    Purpose: To determine function based on keywords
    :param kwargs: Network Request object keywords arguments
    :type kwargs: List
    :return: Function name
    :rtype: str
    """

    if 'id' in kwargs:
        return USERS_GET_FUNCTIONS['id']
    elif 'group' in kwargs:
        return USERS_GET_FUNCTIONS['group']
    else:
        return USERS_GET_FUNCTIONS['all']
