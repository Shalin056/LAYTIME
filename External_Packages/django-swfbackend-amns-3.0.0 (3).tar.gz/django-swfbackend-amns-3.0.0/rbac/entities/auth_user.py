# pylint: disable = E0401,C0301,C0111,R0903,R0201
"""
Proxy model
"""

from rest_framework import status

from rbac.helper import add_groups_to_user, remove_user_from_groups
from rbac.manager import AuthUserManager
from django.contrib.auth.models import User
# from api.models import CustomUser
from rbac.serializers.User import UserSerializer, UserSuggestionSerializer


class AuthUser(User):
    """
    Proxy Model for User
    """

    objects = AuthUserManager()

    @staticmethod
    def __serialize_groups_many(users):
        """
        Purpose: Serialize the Users with flag many=True
        :param users: Serialize Users
        :type users: QuerySet
        :return: str, status
        :rtype: Serialized data and status
        """

        if users is not None:
            serializer = UserSerializer(users, many=True)
            return serializer.data, status.HTTP_200_OK
        else:
            return None, status.HTTP_204_NO_CONTENT

    @staticmethod
    def get_users_by_id(request, kwargs):
        """
        Purpose: To get user by id
        :param request: Network Request object
        :type request: Request Object
        :param kwargs: Network Request object keywords arguments
        :type kwargs: List
        :return: str, status
        :rtype: Serialized User with status flag
        """

        users = AuthUser.objects.get_by_id(kwargs['id'])
        if users is not None:
            serializer = UserSerializer(users)
            return serializer.data, status.HTTP_200_OK
        else:
            return None, status.HTTP_204_NO_CONTENT

    @staticmethod
    def get_users_by_group(request, kwargs):
        """
        Purpose: To get user by group name
        :param request: To get user by group name
        :type request: Request Object
        :param kwargs: Network Request object keywords arguments
        :type kwargs: List
        :return: Serialized User with status flag
        :rtype: str, status
        """

        users = AuthUser.objects.get_by_filter(groups__name=kwargs['group'])
        return AuthUser.__serialize_groups_many(users)

    @staticmethod
    def get_all_users(request, kwargs):
        """
        Purpose: To get all users
        :param request: Network Request object
        :type request: Request Object
        :param kwargs: Network Request object keywords arguments
        :type kwargs: List
        :return: Serialized User with status flag
        :rtype: str, status
        """

        users = AuthUser.objects.get_all()
        return AuthUser.__serialize_groups_many(users)

    @staticmethod
    def post(request):
        """
        Purpose: To add user by DB
        :param request: Network Request object
        :type request: Request Object
        :return: Serialized New User with status flag
        :rtype: str, status
        """

        user = User.objects.create_user(username=request['userName'],
                                        password=request['userPassword'])

        add_groups_to_user(request['groups'], user)

        serializer = UserSerializer(user)
        return serializer.data, status.HTTP_201_CREATED

    @staticmethod
    def patch(request, edit_id):
        """
        Purpose: To edit user in DB
        :param request: Network Request object
        :type request: Request Object
        :param edit_id: Id of the user to be edited
        :type edit_id: int
        :return: Serialized Edited User with status flag
        :rtype: str, status
        """

        user = AuthUser.objects.get_by_id(edit_id)

        remove_user_from_groups(user)

        add_groups_to_user(request['groups'], user)

        user.username = request['userName']
        user.password = request['userPassword']

        user.save()

        serializer = UserSerializer(user)
        return serializer.data, status.HTTP_200_OK

    @staticmethod
    def remove(delete_id):
        """
        Purpose: To delete user from DB
        :param delete_id: Id of the user to be deleted
        :type delete_id: int
        :return: Serialized remaining users with status
        :rtype: str, status
        """

        AuthUser.objects.get_by_id(delete_id).delete()
        return AuthUser.get_all_users(None, None), status.HTTP_200_OK

    @staticmethod
    def suggest_users(request):
        """
        Purpose: To filter 10 matching users based on query for drop down suggestion
        :param request: Network Request object
        :type request: Request Object
        :return: Serialized filtered users with status
        :rtype: str, status
        """

        users = AuthUser.objects.get_by_filter(username__icontains=request.GET['query'])[:10]

        if users is not None:
            serializer = UserSuggestionSerializer(users, many=True)
            return serializer.data, status.HTTP_200_OK
        else:
            return None, status.HTTP_204_NO_CONTENT

    class Meta:
        """
            Purpose: proxy->True to override the main functionality of existing WorkflowStateModel
        """
        proxy = True
