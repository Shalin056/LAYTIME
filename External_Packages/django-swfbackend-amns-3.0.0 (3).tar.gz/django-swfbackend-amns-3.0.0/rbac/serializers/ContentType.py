# pylint: disable = E0401,C0301,C0111,R0903,R0201
"""
Content type model serializer
"""

from django.contrib.contenttypes.models import ContentType
from rest_framework.serializers import ModelSerializer


class ContentTypeSerializer(ModelSerializer):
    class Meta:
        model = ContentType
        fields = "__all__"
