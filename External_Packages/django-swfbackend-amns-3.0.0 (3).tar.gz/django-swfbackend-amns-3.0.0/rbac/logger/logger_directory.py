"""
Create the LOGGER Objects
for now i.e
Requests Logger , User Logger
"""

from logging_essar import init_logging


def requests_logger():
    """
    
    :return Returns the Requests Logger Objects: 
    """
    return init_logging(log_name='API_REQUESTS_LOGS', enable_mailing=False)
