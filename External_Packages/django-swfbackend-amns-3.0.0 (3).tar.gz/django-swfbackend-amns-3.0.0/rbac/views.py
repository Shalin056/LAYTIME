# pylint: disable = E0401,C0301,C0111,R0903,R0201
"""
Viewset
"""

from rest_framework.response import Response
from rest_framework.views import APIView

from rbac.constants import USER_MODEL_NAME, GROUP_MODEL_NAME, BASE_MODEL_NAME
from rbac.logger.logger_directory import requests_logger
from rbac.services import GenericService, OtherService

LOG = requests_logger()


class GenericView(APIView):
    """
    Purpose: 1 APIView for all CRUD
    """

    # Service Object for performing CRUD
    service = None

    def initialize_request(self, request, *args, **kwargs):
        """
        Purpose: To initialize service object,
                before executing any further operations
        :param request: Request from Frontend
        :type request: Request Object
        :param args: Request arguments from Frontend
        :type args: List
        :param kwargs: Request keyword arguments from Frontend
        :type kwargs: Request arguments from Frontend
        :return: call to super class's initialize_request
        """

        LOG.info("Initialize Request")

        # Initializing service based on the URL name i.e. User/Group/Permission
        self.service = GenericService(request.resolver_match.url_name)
        return super().initialize_request(request, *args, **kwargs)

    def get(self, request, **kwargs):
        """
        Purpose: To get data using Service
        :param request: Request from Frontend
        :type request: Request Object
        :param kwargs: Request keyword arguments from Frontend
        :type kwargs: Request arguments from Frontend
        :return: Data received from service
        """

        LOG.info("GET Request on {}".format(str(request.resolver_match.url_name)))

        data, get_status = self.service.service_get_request(request, kwargs)

        LOG.info("GET Response on {}, status: {}, Data size: {}"
                 .format(str(request.resolver_match.url_name)
                         , str(get_status), str(len(data))))

        return Response(data, get_status)

    def post(self, request):
        """
        Purpose: To post data using Service
        :param request: Request from Frontend
        :type request: Request Object
        :return: Data received from service
        """

        LOG.info("POST Request on {}".format(str(request.resolver_match.url_name)))

        data, post_status = self.service.service_post_request(request)

        LOG.info("POST Response on {}, status: {}, Data size: {}"
                 .format(str(request.resolver_match.url_name)
                         , str(post_status), str(len(data))))

        return Response(data, post_status)

    def patch(self, request, **kwargs):
        """
        Purpose: To patch data using Service
        :param request: Request from Frontend
        :type request: Request Object
        :param kwargs: Request keyword arguments from Frontend
        :type kwargs: Request arguments from Frontend
        :return: Data received from service
        """

        LOG.info("PATCH Request on {}, for id: {}".format(str(request.resolver_match.url_name)
                                                          , str(kwargs['id'])))

        data, patch_status = self.service.service_patch_request(kwargs['id'], request)

        LOG.info("PATCH Response on {}, for id: {}, status: {}, Data: {}".format(
            str(request.resolver_match.url_name), str(kwargs['id']),
            str(patch_status), str(data)))

        return Response(data, patch_status)

    def delete(self, request, *args, **kwargs):
        """
        Purpose: To delete data using Service
        :param request: Request from Frontend
        :type request: Request Object
        :param args: Request arguments from Frontend
        :type args: List
        :param kwargs: Request keyword arguments from Frontend
        :type kwargs: Request arguments from Frontend
        :return: Data received from service
        """

        LOG.info("DELETE Request on {}, for id: {}".format(str(request.resolver_match.url_name)
                                                           , str(kwargs['id'])))

        data, delete_status = self.service.service_delete_request(kwargs['id'])

        LOG.info("DELETE Response on {}, for id: {}, status: {}".format(
            str(request.resolver_match.url_name), str(kwargs['id']), str(delete_status)))

        return Response(data, delete_status)


class Suggest(APIView):
    """
    For suggesting user/groups/models
    """

    @staticmethod
    def get(request, **kwargs):
        """
        Purpose: To get suggestions from service
        :param request: Request from Frontend
        :type request: Request Object
        :param kwargs: Request keyword arguments from Frontend
        :type kwargs: Request arguments from Frontend
        :return: Data received from service
        """

        LOG.info("GET Request on {}".format(str(request.resolver_match.url_name)))

        data, suggest_status = None, None

        # Selecting function call based on keyword arguments

        if kwargs['type'] == USER_MODEL_NAME:
            data, suggest_status = OtherService.suggest_user(request)
        if kwargs['type'] == GROUP_MODEL_NAME:
            data, suggest_status = OtherService.suggest_group(request)
        if kwargs['type'] == BASE_MODEL_NAME:
            data, suggest_status = OtherService.suggest_model(request)

        LOG.info("GET Response on {}, status: {}, Data size: {}".format(
            str(request.resolver_match.url_name), str(suggest_status), str(len(data))))

        return Response(data, suggest_status)
