# pylint: disable = E0401,C0301,C0111,R0903,R0201
"""
Service Layer
"""

from django.apps import apps
from jsonpickle import json
from rest_framework import status

from rbac.constants import PERMISSION_MODEL_NAME,\
    GROUP_MODEL_NAME, USER_MODEL_NAME, APP_NAME
from rbac.entities.auth_group import AuthGroup
from rbac.entities.auth_permission import AuthPermission
from rbac.entities.auth_user import AuthUser
from rbac.helper import get_request_object,\
    permission_get_func_selector, group_get_func_selector, \
    user_get_func_selector

# Proxy Model selector
ENTITY_SELECTOR = {
    PERMISSION_MODEL_NAME: AuthPermission(),
    GROUP_MODEL_NAME: AuthGroup(),
    USER_MODEL_NAME: AuthUser(),
}


class GenericService:
    """
    Service Class
    """

    # Entity Object for DB operations
    entity = None

    # Str for determining type of service i.e. User/Group/Permission
    type = None

    def __init__(self, e_type):
        """
        Purpose: Initialize type of service
        :param e_type: Entity type
        :type e_type: str
        """
        self.type = e_type
        self.entity = ENTITY_SELECTOR[e_type]

    def service_get_request(self, request, kwargs):
        """
        Purpose: To get data from Entity
        :param request: Network Request object
        :type request: Request Object
        :param kwargs: Network Request object keywords arguments
        :type kwargs: List
        :return: Data received from Entity
        """

        func = None

        # Selecting GET Function Variants based on type of service
        if self.type == PERMISSION_MODEL_NAME:
            func = getattr(self.entity,
                           permission_get_func_selector(kwargs, request))
        if self.type == GROUP_MODEL_NAME:
            func = getattr(self.entity,
                           group_get_func_selector(kwargs))
        if self.type == USER_MODEL_NAME:
            func = getattr(self.entity,
                           user_get_func_selector(kwargs))

        return func(request, kwargs)

    def service_post_request(self, request):
        """
        Purpose: To post data in Entity
        :param request: Network Request object
        :type request: Request Object
        :return: Data received from Entity
        """

        req_obj = get_request_object(request.data)
        return self.entity.post(req_obj)

    def service_patch_request(self, edit_id, request):
        """
        Purpose: To patch data in Entity
        :param edit_id: Id of the data to be edited
        :type edit_id: int
        :param request: Network Request object
        :type request: Request Object
        :return: Data received from Entity
        """

        req_obj = get_request_object(request.data)
        return self.entity.patch(req_obj, edit_id)

    def service_delete_request(self, delete_id):
        """
        Purpose: To delete data from Entity
        :param delete_id: Id of the data to be deleted
        :type delete_id: int
        :return: Data received from Entity
        """

        return self.entity.remove(delete_id)


class OtherService:
    """
    Purpose: Providing operations other than CRUD
    """

    @staticmethod
    def suggest_user(request):
        """
        Purpose: Suggests user based on query params
        :param request: Network Request object
        :type request: Request Object
        :return: Data received from Entity
        """

        return AuthUser.suggest_users(request)

    @staticmethod
    def suggest_group(request):
        """
        Purpose: Suggests groups based on query params
        :param request: Network Request object
        :type request: Request Object
        :return: Data received from Entity
        """

        return AuthGroup.suggest_groups(request)

    @staticmethod
    def suggest_model(request):
        """
        Purpose: Suggests models based on query params
        :param request: Network Request object
        :type request: Request Object
        :return: Data received from Entity
        """

        models = apps.all_models[APP_NAME]
        return json.dumps(list(models)), status.HTTP_200_OK
