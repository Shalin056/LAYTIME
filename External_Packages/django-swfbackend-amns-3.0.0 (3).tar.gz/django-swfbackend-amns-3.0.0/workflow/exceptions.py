class ActionAlreadyTakenException(Exception):

    def __init__(self, approver, msg='Action Already Taken by this group -- '):
        self.approver = approver
        self.msg = msg + approver
        super().__init__(self.msg)


class NoMatchingTransitionFoundException(Exception):

    def __init__(self, msg='No Matching Transition Master Found'):
        self.msg = msg
        super().__init__(self.msg)


class RejectionDeniedException(Exception):

    def __init__(self, msg='Rejection denied, As no transaction found'):
        self.msg = msg
        super().__init__(self.msg)

class InvalidActionException(Exception):

    def __init__(self, msg='Invalid User Action'):
        self.msg = msg
        super().__init__(self.msg)

class NextApproverNotFoundException(Exception):

    def __init__(self, msg='Next Approver Not Found Exception Raised'):
        self.msg = msg
        super().__init__(self.msg)

class NextTransitionNotFoundException(Exception):

    def __init__(self, msg='Next Sequential Transition Not Found Exception Raised'):
        self.msg = msg
        super().__init__(self.msg)

class ModelNotRegisteredWithWorkflowException(Exception):

    def __init__(self, model_name, msg='Workflow Not Registered With Model -- '):
        self.model = model_name
        self.msg = msg + self.model
        super().__init__(self.msg)

class MatchingApproverGroupNotFoundException(Exception):

    def __init__(self, msg='No Matching Approver Group Found'):
        self.msg = msg
        super().__init__(self.msg)

class MailFailedToApproverNotFoundException(Exception):

    def __init__(self, msg='Next Approvers to Mail Not Found, Hence No Mail Triggered'):
        self.msg = msg
        super().__init__(self.msg)

class NoUsersFoundInGroupException(Exception):

    def __init__(self, group, msg='No Users Found in Group -- '):
        self.msg = msg + group
        super().__init__(self.msg)
        
        
class NoBackwardTransitionFoundException(Exception):
    
    def __init__(self):
        super(NoBackwardTransitionFoundException, self).__init__()


class EditThresholdReachedException(Exception):
    def __init__(self):
        self.msg = "Current transition strength achieved, can't allow Further edits."
        super().__init__(self.msg)


class MultipleTransitionForTransaction(Exception):

    def __init__(self):
        self.msg = "Multiple Transition Found for current coming Transaction"
        super().__init__(self.msg)





