from django.contrib import admin

from . import models


admin.site.register(models.WorkflowTransactions)
admin.site.register(models.WorkflowConstraintsMaster)
admin.site.register(models.WorkflowActionMaster)
admin.site.register(models.WorkflowTransitionsMaster)
admin.site.register(models.ApprovalLinkSent)
admin.site.register(models.InterParallelApproverRules)
