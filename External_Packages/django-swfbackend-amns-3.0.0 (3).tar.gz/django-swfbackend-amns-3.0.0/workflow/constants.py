"""
App / Module level constants
"""

WORKFLOW_ACTION_TYPES = (
    ('Init', 'Init'),
    ('Improve', 'Improve'),
    ('Approve', 'Approve'),
    ('Reject', 'Reject')
)

ACTION_VALIDATOR = {
    "approval": 1,
    "rejection": 2,
    "init": 3,
    "invalid": 4
}

WORKFLOW_STATUS = {
    "Initiated": "Initiated",
    "Draft": "Draft",
    "Final": "Final",
    "Approve": ["Approve", "Forward to L2"],
    "Reject": "Reject",
}

APPROVAL_GROUPS = ["L1","L2","L3","nectar"]  # move




# MODELS_WITH_MAIL_APPROVAL = [] #move


APPROVAL_HEADER = 'HTTP_APPROVAL_AUTHORIZATION'
