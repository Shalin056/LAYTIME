import json

from django.conf import settings


MODELS_FOR_HOOK = settings.__dict__['_wrapped'].__dict__['MODELS_FOR_HOOK']



def is_model_eligible_for_hook(app_name, model_name):
    return model_name in MODELS_FOR_HOOK[app_name]

