# """
# email_policy.py = Default Email Policy
# """
#
from django.apps import apps
from django.conf import settings
from django.contrib.auth.models import User
from django.db.models import Q
from django.utils.module_loading import import_string

from api.logger_directory import requests_logger
from commons.functions import get_hooks
from .models import WorkflowTransactions
from .utils import is_model_eligible_for_hook

REQUESTS_LOG = requests_logger()

WORKFLOW_EMAIL_POLICY = settings.__dict__['_wrapped'].__dict__['WORKFLOW_EMAIL_POLICY']


def get_workflow_email_config(app, model, action):
    """
    :param app:
    :param model:
    :param action:
    :return:
    """

    DEFAULT_POLICY = WORKFLOW_EMAIL_POLICY.copy()
    CONFIG_NAME = 'WORKFLOW_EMAIL_POLICY'

    # Setting the variable function will return
    POLICY_DICT = get_hooks(app, CONFIG_NAME, DEFAULT_POLICY.copy())

    if POLICY_DICT == DEFAULT_POLICY:
        POLICY_DICT = POLICY_DICT.get('default').get(action)
    else:
        POLICY_DICT = POLICY_DICT.get(model).get(action)
        if not POLICY_DICT:
            return DEFAULT_POLICY.get('default').get(action)

    if POLICY_DICT != DEFAULT_POLICY.get('default').get(action):
        REQUESTS_LOG.info("Model specific hook : {}".format(POLICY_DICT))
        REQUESTS_LOG.info("Substituting unspecified actions if any in app hook")
        # Filling in notification type and connected email policy function path if the same
        # not specified in the app's hook function
        for notification_type, hook_path in DEFAULT_POLICY.get('default').get(action).items():
            if notification_type not in POLICY_DICT:
                REQUESTS_LOG.info("Adding {} : {}".format(notification_type, hook_path))
                POLICY_DICT.update({notification_type: hook_path})

        print("After substitution : {}".format(POLICY_DICT))

    return POLICY_DICT


def get_request_initiator(workflow_log):
    initiator = []

    context_model = apps.get_model(workflow_log.app_name, workflow_log.model_name)
    context_object = context_model.objects.get(pk=workflow_log.request_id)

    initiator = list(User.objects.filter(username=context_object.created_by).values_list('email', flat=True))
    WORKFLOW_HOOK = settings.__dict__['_wrapped'].__dict__['WORKFLOW_HOOK']
    if WORKFLOW_HOOK and is_model_eligible_for_hook(workflow_log.app_name, workflow_log.model_name):
        hook_class = import_string(WORKFLOW_HOOK)
        hook_object = hook_class()
        initiator = hook_object.get_custom_request_initiator(workflow_log, context_object.created_by)
        if initiator:
            return initiator
    # init_log = WorkflowTransactions.objects.filter(
    #     app_name=workflow_log.app_name,
    #     model_name=workflow_log.model_name,
    #     request_id=workflow_log.request_id,
    #     action='Init')
    #
    # if init_log.exists():
    #     init_username = init_log.first().approver
    #     initiator = list(User.objects.filter(username=init_username) \
    #                      .values_list('email', flat=True).distinct())

    return initiator


def notify_next_level(workflow_log):
    user_list = []

    filters = Q(~Q(email=None) & ~Q(email=''))

    # get the rows corresponding to the models
    if workflow_log.next_approver_type == "Group":
        filters = Q(filters & Q(groups__name=workflow_log.next_approver))
    elif workflow_log.next_approver_type == "User":
        filters = Q(filters & Q(username=workflow_log.next_approver))

    user_list = User.objects.filter(filters) \
        .values_list("email", flat=True).distinct()
    WORKFLOW_HOOK = settings.__dict__['_wrapped'].__dict__['WORKFLOW_HOOK']
    if WORKFLOW_HOOK and is_model_eligible_for_hook(workflow_log.app_name, workflow_log.model_name):
        hook_class = import_string(WORKFLOW_HOOK)
        hook_object = hook_class()
        user_list = hook_object.get_custom_notify_next_level(workflow_log)
        if user_list:
            return user_list
    return list(user_list)


def notify_previous_level(workflow_log):
    user_list = []
    roles = []

    filters = {}

    last_transactions = WorkflowTransactions.objects.filter(model_name=workflow_log.model_name,
                                                            next_state=workflow_log.current_state)

    print(last_transactions)

    if last_transactions.filter(approver_type="User"):
        filters = {"username__in": last_transactions.values_list('approver', flat=True).distinct()}
    elif last_transactions.filter(approver_type="Group"):
        filters = {"groups__name__in": last_transactions.values_list('approver', flat=True).distinct()}

    user_list = User.objects.filter(**filters).values_list("email", flat=True).distinct()

    REQUESTS_LOG.info("Emails : {}".format(user_list))
    return list(user_list)


#
#
def notify_downstream(workflow_log):
    user_list = []
    roles = []

    filters = get_downstream_users(workflow_log)

    user_list = User.objects.filter(filters) \
        .values_list("email", flat=True).distinct()

    REQUESTS_LOG.info("Emails : {}".format(user_list))

    return list(user_list)


def get_downstream_users(workflow_log, workflow_transitions=[]):
    roles = []

    filters = {
        'model_name': workflow_log.model_name,
        'app_name': workflow_log.app_name
    }

    if workflow_transitions:
        transitions = workflow_transitions

        # Find roles for role based transaction
        groups = transitions.filter(action_group__isnull=False).values_list('action_group', flat=True)
        users = transitions.filter(action_user__isnull=False).values_list('action_user', flat=True)

    else:
        transactions = WorkflowTransactions.objects.filter(pk__lt=workflow_log.pk,
                                                           model_name=workflow_log.model_name,
                                                           app_name=workflow_log.app_name)

        # Find roles for role based transaction
        groups = transactions.filter(approver_type="Group").values_list('approver', flat=True)
        users = transactions.filter(approver_type="User").values_list('approver', flat=True)

    filters = Q(Q(username__in=users) | Q(groups__name__in=groups))

    print("Roles found for downstream users===============", filters)
    return filters


#
def notify_the_hierarchy(workflow_log):
    user_list = []
    usernames = []
    groups = []

    # NOTE: This local import was made only to circumvent a circular import
    from workflow.services import get_hierarchy_by_request

    filters = {
        "model_name": workflow_log.model_name,
        "app_name": workflow_log.app_name,
        "pk": workflow_log.request_id
    }

    all_transitions = get_hierarchy_by_request(filters)

    for each_transition in all_transitions:
        if each_transition.action_group:
            groups.append(each_transition.action_group)
        elif each_transition.action_user:
            usernames.append(each_transition.action_user)

    user_list = User.objects.filter(
        Q(Q(groups__name__in=groups) | Q(username__in=usernames)))
    REQUESTS_LOG.info("Users : {}".format(user_list))
    email_list = user_list.values_list('email', flat=True).distinct()
    REQUESTS_LOG.info("Emails : {}".format(email_list))
    return list(email_list)
