import traceback

from rest_framework import status
from rest_framework.authentication import TokenAuthentication, SessionAuthentication
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.views import APIView

from api.logger_directory import requests_logger
from commons.backends import WorkflowAuthentication
from workflow.serializers import WorkflowTransitionSerializer, WorkflowTransactionSerializer
from workflow.services import get_hierarchy_by_request, apply_workflow_action, get_model_info, \
    get_all_transactions, indicate_approval_type

from workflow.logger import WORKFLOW_LOGS

from api.utils import retrieve_correct_app

from workflow.services import to_show_approval_button


class WorkflowHierarchy(APIView):

    def get(self, request):
        response_data = get_hierarchy_by_request(request.GET)
        if response_data:
            serialize_data = WorkflowTransitionSerializer(response_data, many=True)
            return Response(data=serialize_data.data, status=status.HTTP_200_OK)
        else:
            return Response(status=status.HTTP_400_BAD_REQUEST)


class WorkflowTransactions(APIView):

    def get(self, request):
        response_data = get_all_transactions(request.GET)
        serialize_data = WorkflowTransactionSerializer(response_data, many=True)
        return Response(data=serialize_data.data, status=status.HTTP_200_OK)


class GetApprovalModel(APIView):
    authentication_classes = [WorkflowAuthentication]

    def get(self, request):
        response = get_model_info(request)
        if response:
            final_response = Response(response, status=200)
            return final_response

        return Response(status=400)


class UpdateWorkflow(APIView):
    authentication_classes = [TokenAuthentication, WorkflowAuthentication]

    def patch(self, request, **kwargs):
        try:
            response = apply_workflow_action(request)
            return response
        except Exception as exc:
            WORKFLOW_LOGS.info("Exception occurred")
            WORKFLOW_LOGS.exception(traceback.format_exc())
            return Response(str(exc), status=status.HTTP_500_INTERNAL_SERVER_ERROR)


class IndicateApprovalType(APIView):
    authentication_classes = [TokenAuthentication, WorkflowAuthentication]
    def get(self,request, app, model, pk):
        try:


            response = indicate_approval_type(request, app, model, pk)
            return Response(data=response,status=status.HTTP_200_OK)
        except Exception as exc:
            WORKFLOW_LOGS.info("Exception occurred")
            WORKFLOW_LOGS.exception(traceback.format_exc())
            return Response(str(exc), status=status.HTTP_500_INTERNAL_SERVER_ERROR)


class ShowApprovalSectionView(APIView):

    authentication_classes = [TokenAuthentication, SessionAuthentication]
    permission_classes = [IsAuthenticated]

    def get(self, request, app, model):
        try:
            if not 'id' in request.query_params:
                raise Exception('ID Query Params Required, while fetching show_approval_button')
            app_name, model_obj = retrieve_correct_app(model)
            temp = {'show_section': to_show_approval_button(request, request.query_params.get('id'), model_obj),
                    'show_card': True}
            return Response(temp, status=status.HTTP_200_OK)
        except Exception as e:
            WORKFLOW_LOGS.exception(e)
            return Response(str(e), status=status.HTTP_500_INTERNAL_SERVER_ERROR)