"""
Url patterns
"""

from django.urls import path
from .views import WorkflowHierarchy, WorkflowTransactions, GetApprovalModel, \
    UpdateWorkflow, IndicateApprovalType, ShowApprovalSectionView

urlpatterns = [

    path('get-hierarchy', WorkflowHierarchy.as_view()),
    path('get-transactions', WorkflowTransactions.as_view()),
    path('getapprovalmodel', GetApprovalModel.as_view()),
    path('approval', UpdateWorkflow.as_view()),
    path('to-show-approval-button/<str:app>.<str:model>', ShowApprovalSectionView.as_view()),
    path('indicate_approval_type/<str:app>.<str:model>/<int:pk>', IndicateApprovalType.as_view()),

]
