# pylint: disable = E0401,C0301,C0111,R0903,R0201
"""
Model manager which will do something analogous to a DAO.
"""
from django.apps import apps
from django.conf import settings
from django.db import models

from django.contrib.auth.models import Group, User
from django.core.exceptions import FieldDoesNotExist
from django.db.models import IntegerField, AutoField, BigIntegerField, DecimalField, FloatField, \
    PositiveIntegerField, PositiveSmallIntegerField, SmallIntegerField

from commons.manager import BaseManager
from workflow.entities import WorkflowConstraints, WorkflowTransitions

number_fields = [AutoField, BigIntegerField, IntegerField,
                 DecimalField, FloatField, PositiveIntegerField,
                 PositiveSmallIntegerField, SmallIntegerField]

WORKFLOW_MODEL_LIST = settings.__dict__['_wrapped'].__dict__['WORKFLOW_MODEL_LIST']
APPROVAL_GROUPS = settings.__dict__['_wrapped'].__dict__['APPROVAL_GROUPS']
GROUP_WISE_STATUS_MAPPING = settings.__dict__['_wrapped'].__dict__['GROUP_WISE_STATUS_MAPPING']

class WorkFlowManager(models.Manager):

    def get_pending_for_group_user(self, model_obj, request):
        model_name = model_obj._meta.model.__name__
        groups = request.user.groups.all()
        approval_groups = [group.name for group in groups if group.name in APPROVAL_GROUPS]
        if model_name.lower() in WORKFLOW_MODEL_LIST:
            final_status = []
            [final_status.append(GROUP_WISE_STATUS_MAPPING[group]) for group in GROUP_WISE_STATUS_MAPPING
                      if group in approval_groups]
            is_pending_requests_exists = self.filter(is_active=True, is_approved=False, status__in=final_status)
            if is_pending_requests_exists:
                return is_pending_requests_exists
            else:
                return self.none()
        else:
            return self.all()


    def get_approved_for_group_user(self, model_obj, group, user):
        pass

    def get_all_for_group_user(self, model_obj, group, user):
        pass







class WorkflowBaseManager(BaseManager):

    def __init__(self):
        self.model = None
        self.field = None
        super().__init__()

    def is_valid_model(self):
        try:
            self.model = apps.get_model(app_label=self.app_name, model_name=self.model_name)
            return True
        except LookupError:
            print("Model does not exist")
            return False

    def is_valid_app(self):
        try:
            apps.get_app_config(app_label=self.app_name)
            return True
        except LookupError:
            print("App does not exist")
            return False


class WorkflowConstraintsManager(WorkflowBaseManager):

    def create_constraint(self):
        if self.valid_constraint():
            constraint = WorkflowConstraints()
            constraint.app_name = self.app_name
            constraint.field_name = self.field_name
            constraint.field_value = self.field_value
            constraint.relational_operator = self.relational_operator
            constraint.model_name = self.model_name
            constraint.save()
            return constraint
        else:
            return None

    def is_valid_constraint(self):

        if self.is_valid_app() and self.is_valid_model() \
                and self.is_valid_field() and self.is_valid_relational_operator():
            return True
        else:
            print("Invalid constraint")
            return False

    def is_valid_field(self):
        try:
            self.field = self.model._meta.get_field(self.field_name)
            return True
        except FieldDoesNotExist:
            print("Field does not exist")
            return False

    def is_valid_relational_operator(self):
        field_type = self.field.get_internal_type()

        if type(field_type) not in number_fields:
            if self.relational_operator not in ["=", "!="]:
                print("Field cannot be compared with the given operator")
                return False
            else:
                return True


class WorkflowTransitionsManager(models.Manager):

    def create_transition(self):
        """
        Purpose: Creating transition entry in the DB
        :return: new created object
        """
        if self.is_valid_app() and self.is_valid_model() \
                and self.is_valid_group() and self.is_valid_user():
            transition = WorkflowTransitions()
            transition.model_name = self.model_name
            transition.app_name = self.app_name
            transition.action_group = self.action_group
            transition.action_user = self.action_user
            transition.constraint = self.constraint
            transition.approval_strength = self.approval_strength
            transition.is_last_transition = self.is_last_transition
            transition.current_state = self.current_state
            transition.action = self.action
            transition.next_state = self.next_state
            transition.save()
            return transition
        else:
            return False

    def is_valid_group(self):
        try:
            Group.objects.get_by_natural_key(self.action_group)
            return True
        except Exception:
            print("Group does not exist")
            return False

    def is_valid_user(self):
        try:
            User.objects.get_by_natural_key(self.action_user)
            return True
        except Exception:
            print("Group does not exist")
            return False



# TODO Find out more use cases
class ApprovalLinksManager(BaseManager):

    def get_all_valid_links(self, **filters):
        return self.filter(is_valid=True, **filters)

    def get_all_invalid_links(self, **filters):
        return self.filter(is_valid=False, **filters)
