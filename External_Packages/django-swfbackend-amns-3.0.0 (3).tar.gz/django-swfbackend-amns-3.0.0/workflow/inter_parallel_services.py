import json

from django.db.models import Q

from workflow.entities import WorkflowTransitions
from workflow.exceptions import NoBackwardTransitionFoundException
from workflow.models import WorkflowTransactions


def try_get_inter_next_approver(current_transition, approvers_coming_from_normal_flow, current_approver, request_id):
    if current_transition.level < current_transition.upto_level_inter_parallel:
        return get_forward_inter_approvers(current_transition, approvers_coming_from_normal_flow, current_approver, request_id)
    else:
        return get_backward_inter_approvers(current_transition, approvers_coming_from_normal_flow, current_approver, request_id)


def get_backward_inter_approvers(current_transition, approvers_coming_from_normal_flow, current_approver, request_id):
    inter_parallel_history_exists = check_history_for_interparallel(current_transition, request_id)
    coming_next_approvers = json.loads(approvers_coming_from_normal_flow)
    to_check_levels = list(range(0, current_transition.level))
    to_check_levels.reverse()

    for level in to_check_levels:
        if inter_parallel_history_exists:
            backward_transition = WorkflowTransitions.objects.filter(level=level, is_inter_parallel=True).first()
            if backward_transition:
                backward_transaction_exists = WorkflowTransactions.objects.filter(current_state=backward_transition.current_state,
                                                                                  next_state=backward_transition.next_state,
                                                                                  model_name=current_transition.model_name,
                                                                                  app_name=current_transition.app_name,
                                                                                  request_id=request_id
                                                                                  ).last()
                if backward_transaction_exists:
                    left_out_approvers = json.loads(backward_transaction_exists.next_approver)
                    if current_approver in left_out_approvers:
                        left_out_approvers.remove(current_approver)

                    # monkey patch here, need to refactor
                    if left_out_approvers.__len__() < 5:
                        return json.dumps(left_out_approvers), False
                    else:
                        # final_approvers = list(set(coming_next_approvers).union(left_out_approvers))
                        return json.dumps(coming_next_approvers), False

                else: raise NoBackwardTransitionFoundException
            else: raise NoBackwardTransitionFoundException


def get_forward_inter_approvers(current_transition, approvers_coming_from_normal_flow, current_approver, request_id):
    coming_next_approvers = json.loads(approvers_coming_from_normal_flow)
    forward_transition = WorkflowTransitions.objects.filter(level=current_transition.upto_level_inter_parallel,
                                                            is_inter_parallel=True).first()
    inter_parallel_history_exists = check_history_for_interparallel(current_transition, request_id)
    if current_transition.is_inter_parallel:
        inter_parallel_constraints = current_transition.INTER_APPROVER_RULES.filter(if_approver=current_approver)
        if inter_parallel_constraints:
            constraint = current_transition.INTER_APPROVER_RULES.get(if_approver=current_approver)
            to_include_inter_approvers = json.loads(constraint.include_to_approver)
            final_approvers = coming_next_approvers + to_include_inter_approvers

            # again getting forward transition remaining next approvers from forward transaction history

            if inter_parallel_history_exists:
                forward_transition = WorkflowTransitions.objects.filter(level=current_transition.upto_level_inter_parallel, is_inter_parallel=True).first()
                if forward_transition:
                    forward_transaction_exists = WorkflowTransactions.objects.filter(
                        current_state=forward_transition.current_state,
                        next_state=forward_transition.next_state,
                        model_name=current_transition.model_name,
                        app_name=current_transition.app_name,
                        request_id=request_id).last()
                    if forward_transaction_exists:
                        left_out_approvers = json.loads(forward_transaction_exists.next_approver)
                        if current_approver in left_out_approvers:
                            left_out_approvers.remove(current_approver)
                        final_approvers = list(set(final_approvers).union(left_out_approvers))
                        return json.dumps(final_approvers), True
            # ends here
            return json.dumps(final_approvers), True

        elif inter_parallel_history_exists:
            forward_transaction_exists = WorkflowTransactions.objects.filter(
                current_state=forward_transition.current_state,
                next_state=forward_transition.next_state,
                model_name=current_transition.model_name,
                app_name=current_transition.app_name,
                request_id=request_id).last()
            if forward_transaction_exists:
                left_out_approvers = json.loads(forward_transaction_exists.next_approver)
                if current_approver in left_out_approvers:
                    left_out_approvers.remove(current_approver)
                # monkey patch need to refactor later i.e generic
                if left_out_approvers.__len__() == 0:
                    last_action_plan_executed = json.loads(forward_transaction_exists.action_plan_executed)
                    alive_approvers = [approver for approver in last_action_plan_executed["strength_distribution"]
                                       if last_action_plan_executed["strength_distribution"][approver] != 0]
                    return json.dumps(alive_approvers), False

                else:
                    final_approvers = list(set(coming_next_approvers).union(left_out_approvers))
                    return json.dumps(final_approvers), False
            else:
                return approvers_coming_from_normal_flow, False

        else:
            return approvers_coming_from_normal_flow, False
    else:
        return approvers_coming_from_normal_flow, False



def try_get_dynamic_current_obj_state(transaction_dict, object_state_from_db, inter_parallel_transactions):

    filters = Q(model_name=transaction_dict["model_name"]) \
              & Q(app_name=transaction_dict["app_name"]) \
              & Q(action=transaction_dict["action"]) \
              & Q(is_active=True)
    for apprv in transaction_dict["approver"]:
        filters &= Q(action_group__icontains='"' + apprv + '"')
    get_from_only_approvers = WorkflowTransitions.objects.filter(filters).first()
    if get_from_only_approvers:
        return get_from_only_approvers.current_state

    last_inter_parallel = inter_parallel_transactions.last()
    last_transaction_next_approver = json.loads(last_inter_parallel.next_approver)
    current_requesting_approvers = transaction_dict["approver"]
    approvers = list(set(current_requesting_approvers).intersection(last_transaction_next_approver))
    filters = Q(model_name=transaction_dict["model_name"]) \
              & Q(app_name=transaction_dict["app_name"]) \
              & Q(action=transaction_dict["action"]) \
              & Q(level=last_inter_parallel.was_upto_level) \
              & Q(is_active=True)
    for apprv in approvers:
        filters &= Q(action_group__icontains='"' + apprv + '"')
    transition = WorkflowTransitions.objects.filter(filters).first()
    if transition:
        return transition.current_state
    else:
        return object_state_from_db





def check_history_for_interparallel(current_transition, request_id):
    inter_parallel_transactions_exists = WorkflowTransactions.objects.filter(model_name=current_transition.model_name,
                                                                             app_name=current_transition.app_name,
                                                                             request_id=request_id,
                                                                             was_inter_parallel=True)
    return inter_parallel_transactions_exists





