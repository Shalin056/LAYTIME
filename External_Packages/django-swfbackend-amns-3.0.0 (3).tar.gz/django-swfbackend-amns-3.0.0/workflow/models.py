# pylint: disable = E0401,C0301,C0111,R0903,R0201
"""
Django Models
"""
import operator
import types
from django.apps import apps
from django.conf import settings
from django.db import models
from django.db.models.base import ModelBase, Model

from .constants import WORKFLOW_ACTION_TYPES

PROJECT_APPS = settings.__dict__['_wrapped'].__dict__['PROJECT_APPS']

class WorkflowActionMaster(models.Model):
    action_type = models.CharField(db_column='Action Type', choices=WORKFLOW_ACTION_TYPES, max_length=15)
    action_label = models.CharField(db_column='Action Label', max_length=100)

    def __str__(self):
        return self.action_label


class WorkflowConstraintsMaster(models.Model):
    """
    Model for storing constraints per transitions
    """
    app_name = models.CharField(max_length=100, db_column="App name")
    model_name = models.CharField(max_length=100, db_column="Model name")
    field_name = models.CharField(max_length=100, db_column="Field name")
    relational_operator = models.CharField(max_length=100, db_column="Relational operator")
    field_value = models.CharField(max_length=100, db_column="Field value")

    def is_satisfied(self, transition, pk):
        """
        Check if the constraint is satisfied
        :param transition: Current transition object
        :param pk: id of the data on which workflow is performed
        :return: boolean
        """
        model = apps.get_model(app_label=[app for app in PROJECT_APPS if app.lower() == transition.app_name][0],
                               model_name=transition.model_name)
        field_data = model.objects.get(pk=pk)

        if "hook__" in self.field_name:
            method_name = self.field_name.split("hook__")[1]
            hook_method = getattr(field_data, method_name)
            if isinstance(hook_method, types.MethodType):
                hook_result = hook_method()
                return self.compare_values(hook_result, self.field_value)

        if "." in self.field_name:
            field_list = self.field_name.split(".")
            field_data = getattr(field_data, field_list[0])
            if len(field_list) > 2:
                field_data = getattr(field_data, field_list[1])
            self.field_name = field_list[-1:][0]

        if field_data:
            if self.field_value.isdigit():
                self.field_value = float(self.field_value) if "." in self.field_value else int(self.field_value)

            if not isinstance(self.field_value, int):
                if self.field_value.lower() in ['true', 'false']:
                    self.field_value = True if self.field_value.lower() == 'true' else False
            object_field_data = getattr(field_data, self.field_name)
            if isinstance(object_field_data, int) or isinstance(object_field_data, float) or isinstance(object_field_data, str):
                object_field_data = object_field_data
            else:
                object_field_data = object_field_data.pk
            if self.compare_values(object_field_data, self.field_value):
                return True
            else:
                return False
        else:
            return False

    def compare_values(self, value1, value2):
        """
        Comparing 2 values with the operator
        :param value1: Value 1
        :param value2: Value 2
        :return: boolean
        """
        if type(value2) != type(value1):
            if type(value1) is bool:
                value2 = True if value2 in (1, "true", "True") else False
            if type(value1) is int:
                value2 = int(value2)
        if self.relational_operator == "=":
            return operator.eq(value1, value2)
        if self.relational_operator == "!=":
            return not operator.eq(value1, value2)
        if self.relational_operator == ">":
            return operator.gt(value1, value2)
        if self.relational_operator == ">=":
            return operator.ge(value1, value2)
        if self.relational_operator == "<":
            return operator.lt(value1, value2)
        if self.relational_operator == "<=":
            return operator.le(value1, value2)

    def __str__(self):
        return "{} {} {}".format(self.field_name, self.relational_operator, self.field_value)


class WorkflowTransitionsMaster(models.Model):
    """
    Model for storing the transitions of a approval workflow
    """
    current_state = models.CharField(max_length=50, db_column="Current State")
    action = models.CharField(db_column="Action", max_length=50, blank=True, null=True, default="Initiated")
    next_state = models.CharField(max_length=50, db_column="Next State")
    model_name = models.CharField(db_column="Model name", max_length=50)
    app_name = models.CharField(db_column="App name", max_length=50)
    action_group = models.CharField(max_length=5000, db_column="Action by Group", null=True, blank=True)
    action_user = models.CharField(max_length=50, db_column="Action by User", null=True, blank=True)
    constraints = models.ManyToManyField(WorkflowConstraintsMaster, db_column="Constraints", blank=True)
    approval_strength = models.PositiveIntegerField(db_column="Approval Strength", default=0)
    is_last_transition = models.BooleanField(default=False, db_column="Is Last Approval")
    level = models.PositiveIntegerField(default=0, db_column="level")
    action_plan = models.TextField(blank=True, null=True, db_column='ACTION_PLAN')
    is_parallel_trans = models.BooleanField(default=False, db_column='IS_PARALLEL')
    is_inter_parallel = models.BooleanField(default=False, db_column='IS_INTER_PARALLEL')
    upto_level_inter_parallel = models.IntegerField(db_column='UPTO_LEVEL_INTER_PARALLEL', blank=True, null=True)
    is_active = models.BooleanField(default=True, db_column='IS_ACTIVE')


    def __str__(self):
        temp = '{}.{} --- "{}" ==> {} ==> "{}", by '.format(
            self.app_name, self.model_name, self.current_state, self.action, self.next_state,
        )

        if self.action_user:
            temp = temp + "user: {}".format(self.action_user)
        else:
            temp = temp + "group: {}".format(self.action_group)

        return temp


class WorkflowTransactions(models.Model):
    """
    Model for storing the transactions happened on the approval workflow
    """

    model_name = models.CharField(db_column="Model name", max_length=50)
    app_name = models.CharField(db_column="App name", max_length=50)
    request_id = models.CharField(db_column="Request Id", max_length=50)
    action = models.CharField(db_column="Action", max_length=50, blank=True, null=True, default="Initiated")
    current_state = models.CharField(db_column="Current State", max_length=50, default="None", null=True, blank=True)
    approver = models.CharField(max_length=3000, db_column="Current Approver", blank=True, null=True)
    approver_type = models.CharField(max_length=30, db_column="Current Approver Type", blank=True, null=True)
    approver_user_if_group = models.CharField(max_length=30, db_column="Approver User if Group", blank=True, null=True)
    next_approver = models.CharField(max_length=3000, db_column="Next Approver", blank=True, null=True)
    next_approver_type = models.CharField(max_length=30, db_column="Next Approver Type", blank=True, null=True)
    next_state = models.CharField(db_column="Next State", max_length=50, default="Draft")
    remarks = models.TextField(max_length=250, db_column="Remarks", blank=True, null=True)
    action_plan_executed = models.TextField(blank=True, null=True)
    level_executed = models.IntegerField(db_column='LEVEL_EXECUTED', blank=True, null=True)
    was_parallel = models.BooleanField(db_column='WAS_PARALLEL', default=False)
    was_inter_parallel = models.BooleanField(default=False, db_column='WAS_INTER_PARALLEL')
    was_upto_level = models.IntegerField(db_column='WAS_UPTO_LEVEL', blank=True, null=True)
    created_date = models.DateTimeField(db_column='CREATED_DATE', auto_now=True)  # Field name made lowercase.

    def __str__(self):
        return "Id {} Action {} performed on {} of {}.{}" \
            .format(self.id, self.action, self.request_id, self.app_name, self.model_name)


class ApprovalLinkSent(models.Model):
    """
    Model to serve as a reference for approval requests sent via mail
    """
    approval_token = models.CharField(db_column='APPROVAL_TOKEN', max_length=30)
    app = models.CharField(db_column='APP', max_length=30)
    model = models.CharField(db_column='MODEL', max_length=30)
    request_id = models.CharField(db_column='REQUEST_ID', max_length=10)
    is_valid = models.BooleanField(db_column='IS_VALID', default=True)
    approver = models.CharField(db_column='APPROVER', max_length=300, null=True)
    receiver_email = models.EmailField(db_column='RECEIVER_EMAIL', max_length=140, blank=True, null=True)
    created_at = models.DateTimeField(db_column='CREATED_AT', auto_now_add=True)
    last_updated_at = models.DateTimeField(db_column='LAST_UPDATED_BY', auto_now=True)

    def __str__(self):
        return (f'{self.approval_token} -- request_id -- {self.request_id} -- user -- {self.approver}')


class InterParallelApproverRules(models.Model):
    if_approver = models.CharField(db_column='IF_APPROVER', max_length=300)
    include_to_approver = models.CharField(db_column='INCLUDE_TO_APPROVER', max_length=500)
    for_transaction = models.ForeignKey(WorkflowTransitionsMaster, on_delete=models.CASCADE, db_column='FOR_TRANSACTION', related_name='INTER_APPROVER_RULES')

    def __str__(self):
        return f'If -- {self.if_approver} -- include -- {self.include_to_approver} -- for constraint -- {self.for_transaction}'

    class Meta:
        unique_together = (('if_approver', 'for_transaction'))