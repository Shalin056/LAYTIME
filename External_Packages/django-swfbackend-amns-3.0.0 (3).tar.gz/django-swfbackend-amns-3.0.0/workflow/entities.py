# pylint: disable = R0903
"""
Proxy models which contains the Business Logic related to business model.
Each functions should be atomic and single responsibility.
The methods should be pure methods should not use anything other than instance variables and args.

"""
import json
import traceback

from django.apps import apps
from django.db import transaction
from django.template.loader import get_template
from django.conf import settings
from django.contrib.auth.models import User
from django.db.models.signals import post_save
from django.dispatch import receiver
from django.utils.crypto import get_random_string
from django.utils.module_loading import import_string

from . import models
from .exceptions import MailFailedToApproverNotFoundException, NoUsersFoundInGroupException
from .logger import WORKFLOW_LOGS
from .models import WorkflowTransactions


WORKFLOW_MAIL_MAP = settings.__dict__['_wrapped'].__dict__['WORKFLOW_MAIL_MAP']
MODELS_WITH_MAIL_APPROVAL = settings.__dict__['_wrapped'].__dict__['MODELS_WITH_MAIL_APPROVAL']
LANDING_PAGE_FMT = settings.__dict__['_wrapped'].__dict__['LANDING_PAGE_FMT']
APPROVAL_GROUPS = settings.__dict__['_wrapped'].__dict__['APPROVAL_GROUPS']
WORKFLOW_EMAIL_CONFIGS = settings.__dict__['_wrapped'].__dict__['WORKFLOW_EMAIL_CONFIGS']
PROJECT_APPS = settings.__dict__['_wrapped'].__dict__['PROJECT_APPS']

class WorkflowAction(models.WorkflowActionMaster):

    def is_approval(self):
        return self.action_type == 'Approve'

    def is_rejection(self):
        return self.action_type == 'Reject'

    def is_init(self):
        return self.action_type == 'Init'

    def is_improvement(self):
        return self.action_type == 'Improve'

    class Meta:
        proxy = True


class WorkflowConstraints(models.WorkflowConstraintsMaster):
    class Meta:
        proxy = True


class WorkflowTransitions(models.WorkflowTransitionsMaster):

    class Meta:
        proxy = True


class WorkflowLog(models.WorkflowTransactions):

    class Meta:
        proxy = True


def generate_links_for_groups(instance):
    next_approver = json.loads(instance.next_approver)
    app_name = [app for app in PROJECT_APPS if app.lower() == instance.app_name][0]
    mail_key = app_name + '.' + str(instance.model_name).lower()
    if not next_approver:
        if mail_key in WORKFLOW_EMAIL_CONFIGS:
            WORKFLOW_LOGS.info(
                f'Mail Hook Exists for -- {mail_key} -- instance -- {instance}')
            mail_hook = import_string(WORKFLOW_EMAIL_CONFIGS[mail_key])
            mail_hook(None, instance, None)
    else:
        # if next_approver:
        for group in next_approver:
            users = User.objects.filter(groups__name__iexact=group)
            for user in users:
                if instance.action == 'Init':
                    approval_entry = create_approval_link_entry(instance, user.username, user.email)
                else:
                    approval_entry = get_existing_link_for_instance(instance, user)
                    if not approval_entry:
                        approval_entry = create_approval_link_entry(instance, user.username, user.email)
                WORKFLOW_LOGS.debug(f'Triggering Mail Hook for instance -- {instance} -- Appproval Link -- {approval_entry}')
                if mail_key in WORKFLOW_EMAIL_CONFIGS:
                    WORKFLOW_LOGS.info(f'Mail Hook Exists for -- {mail_key} -- instance -- {instance} -- Link -- {approval_entry}')
                    mail_hook = import_string(WORKFLOW_EMAIL_CONFIGS[mail_key])
                    mail_hook(approval_entry, instance, group)
        # else:
        #     WORKFLOW_LOGS.debug(f'Next Approvers Not Found, hence raised MailFailedToApproverNotFoundException')
        #     raise MailFailedToApproverNotFoundException

def get_existing_link_for_instance(instance, user):
    approval_entry = ApprovalLinkProxy.objects.filter(app__iexact=instance.app_name, model__iexact=instance.model_name,
                                                   request_id=instance.request_id, is_valid=True,
                                                   approver=user)
    if approval_entry:
        return approval_entry[0]
    else:
        return None

def trigger_workflow_mail(approval_entry, instance):
    model_obj = apps.get_model(instance.app_name, instance.model_name)
    obj = model_obj.objects.get(pk=int(instance.request_id))
    url = LANDING_PAGE_FMT.format(approval_entry.approval_token)
    mail_subject, template = get_subject_and_template_from_instance(instance)
    mail_content = render_html_as_email_template(template, context={'obj': obj, 'url': url})
    if approval_entry.receiver_email:
        pass
    else:
        trigger_mails_to_group_members()

def trigger_mails_to_group_members():
    pass

class ApprovalLinkProxy(models.ApprovalLinkSent):
    """
    Proxy model for ApprovalLinkSent
    """

    def self_invalidate(self, to_invalidate_all=True):
        """
        Invalidate any approval attempts using this current approval_token
        by setting has_expired to True
        """
        self.is_valid = False
        self._invalidate_others = to_invalidate_all
        self.save()

    class Meta:
        proxy = True


@receiver(post_save, sender=ApprovalLinkProxy)
def approvalproxy_postsave(sender, instance, **kwargs):
    WORKFLOW_LOGS.debug("POSTSAVE signal triggered")
    if not kwargs.get('created'):
        WORKFLOW_LOGS.info("ApprovalLinkSent ID {} was updated".format(instance.pk))
        if hasattr(instance, '_invalidate_others'):
            # IDEA: Invalidate all other approval links for the same model entry

            if instance._invalidate_others is False:
                return

            WORKFLOW_LOGS.debug("Entering section : Expire approval links for same model")
            # deleting temporary flag
            del instance._invalidate_others

            WORKFLOW_LOGS.info("Finding any valid links for {} object, ID {}".format(instance.model,
                                                                                instance.request_id))
            other_active_links = ApprovalLinkProxy.objects \
                .filter(
                app__iexact=instance.app,
                model__iexact=instance.model,
                request_id=instance.request_id,
                is_valid=True)

            if other_active_links.exists():
                WORKFLOW_LOGS.info("There are {} approval links to expire".format(
                    other_active_links.count()))
                is_updated = other_active_links.update(is_valid=False)

                WORKFLOW_LOGS.info("Return value : {}, Type : {}".format(is_updated, type(is_updated)))
            else:
                WORKFLOW_LOGS.info("Could not find any valid approval links to expire")

            # Invalidate all tokens for the current user and the guest user
            # Token.objects.filter(user__username__in=[instance.approver, 'guest']).delete()

            WORKFLOW_LOGS.debug("Leaving section : Expire approval links for same model")


# TODO Make default_hook optional
def create_approval_link_entry(workflow_log, username, receiver_email):
    """
    QUESTION : Is this an entity function ?
    Function to create Approval Link entries
    These entries will be the reference when approval POST
    requests will be made from the landing page

    :param workflow_log: Workflow log recieved from postsave call
    :type workflow_log: WorkflowState object
    :param receiver_email: Receiver email
    :type receiver_email
    :return:
    """
    # QUESTION : receiver_email is a list of email addresses. Is this okay ?

    approval_entry = ApprovalLinkProxy.objects.create(
        approval_token=get_random_string(length=13),
        app=workflow_log.app_name,
        model=workflow_log.model_name,
        request_id=workflow_log.request_id,
        approver=username,
        receiver_email=receiver_email
    )
    return approval_entry


def get_subject_and_template_from_instance(instance):
    app = instance.app_name
    app_configs = WORKFLOW_EMAIL_CONFIGS[app]
    my_item = next((item for item in app_configs if item['model'] == instance.model_name
                    and item['current_state'] == instance.current_state
                    and item['action'] == instance.action), None)
    if my_item:
        return my_item['subject'], my_item['template']
    else:
        return None, None


def render_html_as_email_template(email_code, context={}):
    html_template = get_template(email_code + ".html")
    mail_content = html_template.render(context)
    return mail_content
