"""
hooks.py - Default hooks defined. If the user does not provide app-specific hooks
with similar config names, these will be used.
"""

# NOTE: For Email Policy hook structures
# Previous structures used, which allowed only a single notification
# ROLE_WORKFLOW_EMAIL_POLICY = {
#     'default':{
#         'action':'dotted.path.to.the.function',
#         'Approve':'workflow.email_policy.notify_next_level',
#     }
# }
# New Structure to allow multiple emails
# ROLE_WORKFLOW_EMAIL_POLICY = {
#     'default':{
#         'action' : {
#             'notification_type' : 'dotted.path.to.the.function',
#             'alert': 'workflow.email_policy.notify_previous_level'
#         }
#     }
# }

WORKFLOW_EMAIL_POLICY = {
    'default': {
        'Init':{
          'request' : 'swbackend.workflow.email_policy.notify_next_level',
        },
        'Approve': {
            'request': 'swbackend.workflow.email_policy.notify_next_level',
            'notification': 'swbackend.workflow.email_policy.notify_previous_level'
        },
        'Reject': {
            'notification': 'swbackend.workflow.email_policy.notify_downstream'
        },
        'Improve': {
            'notification': 'swbackend.workflow.email_policy.notify_previous_level'
        },
    }
}

# HIERARCHY_EMAIL_POLICY = {
#     'default': {
#         # 'Init':{
#         #   'request' : '',
#         # },
#         'Approve': {
#             'request': 'workflow.email_policy.notify_next_user',
#             'notification': 'workflow.email_policy.notify_last_user'
#         },
#         'Reject': {
#             'notification': 'workflow.email_policy.notify_the_hierarchy'
#         },
#         'Improve': {
#             'notification': 'workflow.email_policy.notify_last_user'
#         }
#     }
# }

WORKFLOW_ACTIONS_TRIGGER = {

}
