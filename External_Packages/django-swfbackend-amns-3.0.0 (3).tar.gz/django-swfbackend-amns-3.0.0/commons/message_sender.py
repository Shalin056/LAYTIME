#import pika
import pika
from django.conf import settings

RABBITMQ_CONF = settings.__dict__['_wrapped'].__dict__['RABBITMQ_CONF']

RABBITMQ_CON_URL = RABBITMQ_CONF["RABBITMQ_CON_URL"]
RABBITMQ_QUEUE = RABBITMQ_CONF["RABBITMQ_QUEUE"]


mail_dict = {
    'subject': 'Default Subject',
    'message': 'Your Message',
    'from_email': RABBITMQ_CONF["SENDER_MAIL"],
    'recipient_list': [],
    'cc': [],
    'html_message': 'HTML Messaage',
}


def rabbit_connection():
    """
    This function establishes connection with RabbitMQ server.
    :return: RabbitMQ Channel
    :rtype: channel
    """
    global channel, connection

    connection = pika.BlockingConnection(pika.URLParameters(RABBITMQ_CON_URL))
    channel = connection.channel()
    channel.queue_declare(queue=RABBITMQ_QUEUE)
    return channel


def send_message(channel, body):
    """
    Sends message to RabbitMQ server
    :param mail_dict:
    :type mail_dict:
    :return:
    :rtype:
    """
    channel.basic_publish(exchange='',
                          routing_key=RABBITMQ_QUEUE,
                          body=body)
