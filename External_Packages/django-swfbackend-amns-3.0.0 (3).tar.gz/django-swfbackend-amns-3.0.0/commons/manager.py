from django.db import models

class BaseManager(models.Manager):
    def get_all(self):
        return super(BaseManager, self).all()

    def get_all_undeleted(self):
        return super(BaseManager, self).all().filter(is_deleted=False)
    
    def get_all_deleted(self):
        return super(BaseManager, self).all().filter(is_deleted=True)
    
    def get_by_pk(self, pk):
        return super(BaseManager, self).get(pk=pk)

    def get_multiple_pk(self, pk_list):
        return super(BaseManager, self).filter(pk__in=pk_list)
    
    def get_by_filter(self, filters):
        return super(BaseManager, self).filter(**filters)