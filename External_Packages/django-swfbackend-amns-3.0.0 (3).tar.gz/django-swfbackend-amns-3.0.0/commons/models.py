from django.db import models

#
# class MasterBaseModel(models.Model):
#
#     # status = models.CharField(db_column='status', null=True, blank=True, default="Draft", max_length=100)
#     is_approved = models.BooleanField(db_column='IS_APPROVED', default=False)
#     is_active = models.BooleanField(db_column='IS_ACTIVE', blank=True, null=True,
#                                     default=True)  # Field name made lowercase.
#     is_deleted = models.BooleanField(db_column='IS_DELETED', blank=True, null=True,
#                                      default=False)  # Field name made lowercase.
#     created_by = models.CharField(db_column='CREATED_BY', max_length=50, blank=True,
#                                   null=True)  # Field name made lowercase.
#     created_date = models.DateTimeField(db_column='CREATED_DATE', blank=True, null=True,
#                                         auto_now_add=True)  # Field name made lowercase.
#     last_updated_by = models.CharField(db_column='LAST_UPDATED_BY', max_length=50, blank=True,
#                                        null=True)  # Field name made lowercase.
#     last_updated_date = models.DateTimeField(db_column='LAST_UPDATED_DATE', blank=True,
#                                              null=True, auto_now=True)  # Field name made lowercase.
#
#     class Meta:
#         abstract = True
