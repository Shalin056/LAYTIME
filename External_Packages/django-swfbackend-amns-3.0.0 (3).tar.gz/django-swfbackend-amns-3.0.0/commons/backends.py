from django.contrib.auth.models import User
from rest_framework.authentication import BaseAuthentication
from rest_framework.exceptions import AuthenticationFailed, MethodNotAllowed

from workflow.models import ApprovalLinkSent


class WorkflowAuthentication(BaseAuthentication):

    def get_approval_token_header(self, request):
        """
        Get Approval-Authentication param from request headers

        NOTE: All custom headers (such as this) should be included
              in CORS_ALLOW_HEADERS list in settings.py

        :param request: Network request object
        :type request: HttpRequest
        :return: Approval-Authorization token
        :rtype: str
        """
        # Approval-Authorization is converted to HTTP_APPROVAL_AUTHORIZATION

        token_received = request.META.get('HTTP_APPROVAL_AUTHORIZATION')
        return token_received


    def authenticate(self, request, **kwargs):
        vetted_user = None
        token_from_ui = self.get_approval_token_header(request)

        if request.method.lower() not in ['get','patch','options']:
            raise MethodNotAllowed("Illegal operation : {} is not allowed".format(request.method))

        if not token_from_ui:
            error_msg = "Insufficient parameters"
            raise AuthenticationFailed(error_msg)
        else:
            # IDEA: Check if the sent token exists in the ApprovalLinksSent model
            token_in_db = ApprovalLinkSent.objects.filter(approval_token=token_from_ui, is_valid=True)
            if token_in_db.exists():
                # Valid token exists, set User
                approval_token = token_in_db.first()
                vetted_user = User.objects.filter(username=approval_token.approver).first()
                if not vetted_user:
                    raise AuthenticationFailed("Could not find any valid user")
            else:
                # There is no such token, raise exception
                error_msg = "No such token found"
                raise AuthenticationFailed(error_msg)

        return vetted_user, token_from_ui