"""
for custom Exceptions
"""

class EmptyBodyException(Exception):
    pass
