"""
LDAP connection for
the Given Servers in the List

"""
from ldap3 import Server, Connection, AUTO_BIND_TLS_BEFORE_BIND, AUTO_BIND_NO_TLS


def connection(srvr, username, password, raise_exceptions=False):
    """
    Connects LDAP for the
    Given Server in the LIST
    """
    server = Server(srvr.hostname, srvr.port, srvr.use_ssl, srvr.get_info,connect_timeout=10)
    conn = Connection(
        server,
        auto_bind=AUTO_BIND_NO_TLS,
        check_names=True,
        user=str(srvr.domain) + '\\' + str(username),
        password=password,
        raise_exceptions=raise_exceptions
    )
    return conn
