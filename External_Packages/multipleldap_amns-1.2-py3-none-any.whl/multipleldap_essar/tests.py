import unittest
from ldap3 import Server, Connection, AUTO_BIND_TLS_BEFORE_BIND
from ldap3.core.exceptions import LDAPBindError, LDAPInvalidCredentialsResult, LDAPSocketOpenError
from .MultiLDAPAuthenticator import LDAPServer, MultipleLDAPAuthenticator
from .connection import connection

srvr = LDAPServer("srhouse", "172.24.102.200", 389)
username = ""
password = ""


class test_user_connection(unittest.TestCase):


    def test_connection(self):
            server = Server(srvr.hostname, srvr.port, srvr.use_ssl, srvr.get_info)
            conn = Connection(
                server,
                auto_bind=AUTO_BIND_TLS_BEFORE_BIND,
                check_names=True,
                user=str(srvr.domain) + '\\' + str(username),
                password=password,
                raise_exceptions=False
            )
            self.assertTrue(conn.bind())

    def test_invalid_credentials(self):
        srvr = LDAPServer("srhouse", "172.24.102.200", 389)
        username = ""
        password = ""

        try:

            server = Server(srvr.hostname, srvr.port, srvr.use_ssl, srvr.get_info)
            conn = Connection(
                server,
                auto_bind=AUTO_BIND_TLS_BEFORE_BIND,
                check_names=True,
                user=str(srvr.domain) + '\\' + str(username),
                password=password,
                raise_exceptions=True
            )
            self.assertTrue(conn.bind())
        except LDAPInvalidCredentialsResult:
            self.assertRaises(LDAPInvalidCredentialsResult)

    def test_connection_error(self):
        srvr = LDAPServer("srhouse", "172.24.102.201", 389)
        username = ""
        password = ""

        try:

            server = Server(srvr.hostname, srvr.port, srvr.use_ssl, srvr.get_info,connect_timeout=10)
            conn = Connection(
                server,
                auto_bind=AUTO_BIND_TLS_BEFORE_BIND,
                check_names=True,
                user=str(srvr.domain) + '\\' + str(username),
                password=password,
                raise_exceptions=True
            )
            self.assertTrue(conn.bind())
        except LDAPSocketOpenError:
            self.assertRaises(LDAPSocketOpenError)



    def test_mutliple_ldap(self):
        MultipleLDAPAuthenticator.setup(servers=[
            LDAPServer("srhouse", "172.24.102.201", 389),
            LDAPServer("srhouse", "172.24.102.200", 389)
        ]
        )
        authenticator = MultipleLDAPAuthenticator()
        res = authenticator.authenticate("ptejas2", "T@epY098")
        if res:
            self.assertTrue(True)


    def test_connect_ONE_and_return(self):
        MultipleLDAPAuthenticator.setup(servers=[
            LDAPServer("srhouse", "172.24.102.200", 389),
            LDAPServer("srhouse", "172.24.102.200", 389)
        ]
        )

        authenticator = MultipleLDAPAuthenticator()
        res = authenticator.authenticate("ptejas2", "T@epY09")
        if res:
            self.assertTrue(True)



    def test_username_existence(self):
        MultipleLDAPAuthenticator.setup(servers=[
            LDAPServer("srhouse", "172.24.102.200", 389),
            LDAPServer("srhouse", "172.24.102.200", 389)
        ]
        )

        authenticator = MultipleLDAPAuthenticator()
        res = authenticator.authenticate("ptejas2", "T@epY098")


        pass




    def test_many_servers_connect_last(self):
        MultipleLDAPAuthenticator.setup(servers=[
            LDAPServer("srhouse", "172.24.102.201", 389),
            LDAPServer("srhouse", "172.24.102.201", 389),
            LDAPServer("srhouse", "172.24.102.201", 389),
            LDAPServer("srhouse", "172.24.102.200", 389)

        ]
        )

        authenticator = MultipleLDAPAuthenticator()
        res = authenticator.authenticate("ptejas2", "T@epY098")
        if res:
            self.assertTrue(True)

    def test_many_servers_connect_between(self):
        MultipleLDAPAuthenticator.setup(servers=[
            LDAPServer("srhouse", "172.24.102.201", 389),
            LDAPServer("srhouse", "172.24.102.201", 389),
            LDAPServer("srhouse", "172.24.102.200", 389),
            LDAPServer("srhouse", "172.24.102.200", 389)

        ]
        )

        authenticator = MultipleLDAPAuthenticator()
        res = authenticator.authenticate("ptejas2", "T@epY098")
        if res:
            self.assertTrue(True)


if __name__ == '__main__':
    unittest.main()







