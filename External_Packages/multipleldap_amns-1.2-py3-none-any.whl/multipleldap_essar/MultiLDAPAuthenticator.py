"""
Module for Multiple LDAP Authentication
First fails , auto reconnect to
Second LDAP server
"""
from ldap3 import ALL, SUBTREE
from ldap3.core.exceptions import LDAPBindError, LDAPInvalidCredentialsResult, LDAPSocketOpenError
from .connection import connection


class LDAPServer:
    """
    Creates the List of LDAP
    Server Objects
    """

    def __init__(self, domain, hostname, port, use_ssl=False, get_info=ALL):
        self.domain = domain
        self.hostname = hostname
        self.port = port
        self.use_ssl = use_ssl
        self.get_info = get_info


class MultipleLDAPAuthenticator():
    """
    Functional Class for LDAP
    Authentication
    """
    servers = []
    RAISE_EXCEPTION = True

    @staticmethod
    def setup(**kwargs):
        MultipleLDAPAuthenticator.servers = list(kwargs.get("servers"))
        if len(MultipleLDAPAuthenticator.servers) < 1:
            raise Exception("Server List cannot be blank , Atleast ONE needed !")
        # elif len(MultipleLDAPAuthenticator.servers) > 2:
        #     raise Exception(" Not More then TWO  servers are Allowed for NOW !")


    def authenticate(self, username, password):
        """
        Tries to Authenticate for
        Given username and Password
        Chronologically
        """
        connection_srvrs = []
        for i in range(len(MultipleLDAPAuthenticator.servers)):
            try:
                srvr = MultipleLDAPAuthenticator.servers[i]
                conn = connection(srvr, username, password,raise_exceptions=True)

                if conn.bind():
                    return {
                        "status": "Success",
                        "server": srvr.hostname,
                        "authentication_log": [{
                            "Username NOT IN" : connection_srvrs,
                            "response": conn.response,
                            "message": conn.result
                        }]
                    },conn
            except (LDAPBindError,LDAPSocketOpenError):
                if i == (len(MultipleLDAPAuthenticator.servers)-1):
                    return {
                    "status": "Failure",
                    "server": srvr.hostname,
                    "authentication_Error": [{
                        " Error "  : "Server Down !!",
                        "Exception" : LDAPSocketOpenError
                    }]
                },None
                else:
                    connection_srvrs.append(srvr.hostname)
                    continue
            except LDAPInvalidCredentialsResult:
                if i == (len(MultipleLDAPAuthenticator.servers)-1):
                    return {
                    "status": "Failure",
                    "server": srvr.hostname,
                    "authentication_Error": [{
                        "Error" : "Invalid Credentials",
                        "Exception" : LDAPInvalidCredentialsResult
                    }]
                },None
                else:
                    connection_srvrs.append(srvr.hostname)
                    continue
            except Exception:
                if i == (len(MultipleLDAPAuthenticator.servers)-1):
                    return {
                    "status": "Failure",
                    "server": srvr.hostname,
                    "authentication_log":  " Unexpected Error "

                },None
                else:
                    connection_srvrs.append(srvr.hostname)
                    continue


    def searchfilter(self, con, base, filter, attributes=[]):
        con.search(
            search_base=base,
            search_filter=filter,
            search_scope=SUBTREE,
            attributes=attributes
        )

        return con.entries

    def extendedSearch(self, con, base, filter, attributes=[]):
        con.extend.standard.paged_search(base, filter, attributes)
        return con.entries














