"""
Configuration module for
Server's setup and
Logger directory path
"""

from .MultiLDAPAuthenticator import LDAPServer, MultipleLDAPAuthenticator


def configuration():
    """
    Setup the Multiple LDAP
    Server Objects
    """
    MultipleLDAPAuthenticator.setup(servers=[
        #LDAPServer("srhouse", "172.24.102.200", 389),
        LDAPServer("MyAMNS", "SRVHAZ300", 389),
        LDAPServer("MyAMNS", "SRVHAZ002", 389),
        # LDAPServer("MyAMNS", "172.24.238.21", 389),
        # LDAPServer("MyAMNS", "150.0.150.80", 389),
    ]
    )






